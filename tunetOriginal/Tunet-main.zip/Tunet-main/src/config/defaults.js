export const DEFAULT_PAGES_CONFIG = {
  header: [],
  pages: ['home'],
  home: []
};

